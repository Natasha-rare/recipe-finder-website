﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using recipe_finder_api.Models;

namespace recipe_finder_api.Controllers
{
    [Route("register")]
    [ApiController]
    public class RegisterController : ControllerBase
    {
        UserContext db;
        public RegisterController(UserContext context)
        {
            db = context;
            
        }
        [HttpPost]
        public async Task<ActionResult<User>> Post(User user)
        {
            
            if (db.Users.Any(x => x.Email == user.Email))
            {
                return BadRequest("User exists!");
            }
            db.Users.Add(user);
            await db.SaveChangesAsync();
            return Ok("Signed up!");
        }

    }
}
