from requests import get, post, put, delete


# print(post("http://localhost:5000/register",
#         json={"name": "Nata",
#               "email": "na@gmail.com",
#               "password": "na1na2"}).json())
#
# print(post("http://localhost:5000",
#         json={"name": "Nata",
#               "email": "na@gmail.com",
#               "password": "na1na2"}).json())

print(get("http://localhost:5000/email=na@gmail.com&password=na1na2").json())
#
# print(put("http://localhost:5000",
#           json={"email": "na@gmail.com",
#                 "password": "na1na2",
#                 "name": "Natasha"}).json())
#
# print(get("http://localhost:5000",
#           json={"email": "na@gmail.com",
#               "password": "na1na2"}).json())
