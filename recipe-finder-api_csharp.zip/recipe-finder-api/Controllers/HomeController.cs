﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using recipe_finder_api.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace recipe_finder_api.Controllers
{
    [Route("/")]
    [ApiController]
    public class HomeController : Controller
    {
        UserContext db;
        public HomeController(UserContext context)
        {
            db = context;
            //if (!db.Users.Any())
            //{
            //    db.Users.Add(new User { Name = "Daniel", Email = "dan@x.ru", Password = "123", SavedLinks = new string[] { "hi", "hello" }, ProductList = new Products[] { } });
            //    db.SaveChanges();
            //}
            db.Users.Include(x => x.SavedLinks).ToList();
            db.Users.Include(x => x.ProductList).ToList();
        }

        [HttpGet]
        public async Task<ActionResult<User>> GetAsync([FromQuery] string email, string pass)
        {
            User user = await db.Users.FirstOrDefaultAsync(x => x.Email == email && x.Password == pass);
            
            if (user == null) return NotFound();
            
            user.Password = "****";

            return new ObjectResult(user);
        }

        [HttpPost]
        public ActionResult<User> Post(User user)
        {

            if (db.Users.Any(x => x.Email == user.Email && x.Password == user.Password))
            {
                return Ok("Logged in!");
            }
            if (db.Users.Any(x => x.Email == user.Email && x.Password != user.Password))
            {

                return BadRequest("Incorrect password!");
            }
            return BadRequest("Need to sign up!");
        }

        [HttpPut]
        public async Task<ActionResult<User>> Put(User user)
        {
            if (user == null)
            {
                return BadRequest();
            }
            if (!db.Users.Any(x => x.Email == user.Email))
            {
                return NotFound();
            }
            if (db.Users.Any(x => x.Password == user.Password && x.Email == user.Email))
            {
                db.Update(user);
                await db.SaveChangesAsync();
                return Ok("Data changed!");
            }
            return BadRequest("Invalid email/password");
        }

        [HttpDelete]
        public void Delete(int id)
        {
        }
    }
}
